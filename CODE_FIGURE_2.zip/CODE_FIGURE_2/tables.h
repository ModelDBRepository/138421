#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#define TAB0 -100.0
#define TAB1 100.0
#define MAXPOINTS 200000

double expTAB[MAXPOINTS];
double tanhTAB[MAXPOINTS];
double thetaTAB[MAXPOINTS];

double TANH(double x);
double EXP(double x);
double THETA(double x);
void makeTables();
double rnd();
double normalrnd();


#include "function.h"
#include "stdio.h"

void superimpose(int k, double t[], double g[], double f[], double h[]) {
// h(t) = f(g(t))
    int i,j;
    double x;
    int flag; 
     
    t[k]=1;
    f[k]=0;
    for(i=0;i<k;i++) {
        x = g[i];
        if(x>1) x=1;
        if(x<0) x=0;
        flag = 0;
        for(j=0;j<k;j++) {
            if(t[j]<=x && x<=t[j+1]) {
                flag=1;
                break;
            }
        }
        if(flag) {
            h[i] = f[j] + (f[j+1]-f[j])*(x-t[j])/(t[j+1]-t[j]);    
        }
        else {
            h[i]=0;
            fprintf(stderr,"[%i %lf]",i,x);
        }
    }
    return;
}

void find_zeroes(int k, double t[], double f[]) {
    int i;
    double fp;
    for(i=0;i<k-1;i++) {
        if(f[i]*f[i+1]<=0) {
            fp = (f[i+1]-f[i])/(t[i+1]-t[i]);
            fprintf(stderr,"t=%2.4lf\tF'=%2.4lf\n",t[i],fp);                   
        }
    }     
}

#include <cstdlib>
#include <iostream>

using namespace std;

#include <cstdlib>
#include <iostream>
#include "math.h"

#include "models.h"

using namespace std;


int main(int argc, char *argv[])
{
    int i,j,k,n;
    double dt = 0.01;
    

    makeTables();  // Tablulates exponential and other function (for speedup)


    Network my_network;
    my_network.set_outfile("OIO_simulation.out");

    WangBuzsakiBasket I(1);
    my_network.addElement(&I);
    I.I_app = 0.25;  // I cell 
   
    SaragaOLM O(2);
    my_network.addElement(&O);
    O.I_app = -6.7; // O cells 
    
    
    
    O.addSynapseFrom(&I,0.2);
    I.addSynapseFrom(&O,0.02);
 
    O.load("o_init_cond2");
    I.load("i_init_cond2");
 
    my_network.reset();
    O.desynchronize(10000,dt);
    my_network.report_mode=REPORT_VOLTAGE;
    my_network.run(300000,dt);
//    O.save("o_init_cond2");
//    I.save("i_init_cond2");

}

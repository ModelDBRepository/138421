#include "math.h"


void superimpose(int k, double t[], double g[], double f[], double h[]);

void find_zeroes(int k, double t[], double f[]);

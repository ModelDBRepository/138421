T=150;
fs=12;

IO = load('strc_IO.out');
OI = load('strc_OI.out');
OO = load('strc_OO.out');
OE = load('strc_OE.out');
x1 = T*OO(:,1);
y1 = T*OO(:,4);
x2 = T*IO(:,1);
y2 = T*IO(:,7);
x3 = T*OI(:,1);
y3 = T*OI(:,5);
x4 = T*OE(:,1);
y4 = T*OE(:,5);

scrsz = get(0,'ScreenSize');
f1=figure('Position',[1 scrsz(4)/2 scrsz(3)*0.35 scrsz(4)*0.35])

h=gca;
set(h,'FontName','Helvetica');
set(h,'FontSize',fs);
set(gcf,'DefaultLineLineWidth',1);
plot(x1,y1,'k-',x2,y2,'k--',x3,y3,'k-.',x4,y4,'k:',x1,0,'k:');
xlabel('\Delta, ms');
ylabel('f(\Delta), ms');
legend('OO','IO','OI','OE');


f2=figure('Position',[1 scrsz(4)/2 scrsz(3)*0.35 scrsz(4)*0.35])
h=gca;
set(h,'FontName','Helvetica');
set(h,'FontSize',fs);
set(gcf,'DefaultLineLineWidth',1);

STDM_OO = load('stdm_OO.out');
STDM_IO = load('stdm_IO.out');
x1 = T*STDM_OO(:,1);
y1 = T*STDM_OO(:,3);
x2 = T*STDM_IO(:,1);
y2 = T*STDM_IO(:,3);


plot(x1,y1,'k-',x2,y2,'k--',x1,0,'k:');
hold on;
x3 = 75;
y3 = 0;
plot(x3,y3, 'MarkerEdgeColor','k','Marker','o', 'MarkerFaceColor','k','MarkerSize',3);
x4 = 114.3;
y4 = 0;
plot(x4,y4, 'MarkerEdgeColor','k','Marker','o', 'MarkerFaceColor','k','MarkerSize',3);
x5 = 0;
y5 = 0;
plot(x5,y5, 'MarkerEdgeColor','k','Marker','o', 'MarkerFaceColor','k','MarkerSize',3);




xlabel('\Delta, ms');
ylabel('F(\Delta), ms');

text(0.5,-1.4,'\Delta_0','FontSize',fs);
text(74.5,-1.4,'\Delta_1','FontSize',fs);
text(113.8,-1.4,'\Delta_2','FontSize',fs);





f3=figure('Position',[1 scrsz(4)/2 scrsz(3)*0.35 scrsz(4)*0.35])
h=gca;
set(h,'FontName','Helvetica');
set(h,'FontSize',fs);
set(gcf,'DefaultLineLineWidth',1);

EIO = load('strc_EIO.out');
x = T*EIO(:,1);
y1 = T*EIO(:,3);
y3 = T*EIO(:,5);
y4 = T*EIO(:,8);


plot(x,y1,'k-',x,y3,'k-.',x,y4,'k:',x,0,'k:');
xlabel('\Delta, ms');
ylabel('f(\Delta), ms');

f4=figure('Position',[1 scrsz(4)/2 scrsz(3)*0.35 scrsz(4)*0.35])
h=gca;
set(h,'FontName','Helvetica');
set(h,'FontSize',fs);
set(gcf,'DefaultLineLineWidth',1);

STDM_IO = load('stdm_EIO.out');
x = T*STDM_IO(:,1);
y1 = T*STDM_IO(:,3);
y3 = T*STDM_IO(:,5);
y4 = T*STDM_IO(:,8);

plot(x,y1,'k-',x,y3,'k-.',x,y4,'k:',x,0,'k:');
hold on;
 
x3 = 116.8;
y3 = 0;
plot(x3,y3, 'MarkerEdgeColor','k','Marker','o', 'MarkerFaceColor','k','MarkerSize',3);
x4 = 122;
y4 = 0;
plot(x4,y4, 'MarkerEdgeColor','k','Marker','o', 'MarkerFaceColor','k','MarkerSize',3);
x5 = 0;
y5 = 0;
plot(x5,y5, 'MarkerEdgeColor','k','Marker','o', 'MarkerFaceColor','k','MarkerSize',3);


xlabel('\Delta, ms');
ylabel('F(\Delta), ms');

text(0.9, 2.5,'\Delta_0','FontSize',fs);
text(114,-3.4,'\Delta_1','FontSize',fs);
text(121.1,-3.4,'\Delta_2','FontSize',fs);

